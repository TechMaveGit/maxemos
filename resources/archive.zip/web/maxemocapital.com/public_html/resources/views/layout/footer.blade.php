<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between px-4 py-3 border-top small">
  <p class="text-muted mb-1 mb-md-0">All the copyright @ 2022 reserved by <a href="javascript:void(0);" target="_blank">AdvanX</a>.</p>
</footer>




